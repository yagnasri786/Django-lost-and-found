from django import forms
from .models import Item

class ItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ['title', 'description', 'category', 'image', 'contact_info', 'location', 'status', 'posted_by_name']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control', 
                'placeholder': 'Enter item title (e.g., Red Backpack)',
                'maxlength': '100'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control', 
                'placeholder': 'Provide detailed description of the item...', 
                'rows': 5
            }),
            'category': forms.Select(attrs={
                'class': 'form-select'
            }),
            'image': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': 'image/*'
            }),
            'contact_info': forms.TextInput(attrs={
                'class': 'form-control', 
                'placeholder': 'Email or Phone Number'
            }),
            'location': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Where was it lost/found? (Optional)'
            }),
            'status': forms.Select(attrs={
                'class': 'form-select'
            }),
            'posted_by_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Your name (e.g., John Doe) - Optional'
            }),
        }
