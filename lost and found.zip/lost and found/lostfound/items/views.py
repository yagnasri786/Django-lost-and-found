from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Count
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.models import User
from .models import Item
from .forms import ItemForm

def home(request):
    items = Item.objects.all().order_by('-date_posted')
    search_query = request.GET.get('q', '')
    category_filter = request.GET.get('category', '')
    sort_by = request.GET.get('sort', '-date_posted')
    
    if search_query:
        items = items.filter(Q(title__icontains=search_query) | Q(description__icontains=search_query) | Q(user__username__icontains=search_query))
    
    if category_filter:
        items = items.filter(category=category_filter)
    
    # Sorting options
    valid_sorts = ['-date_posted', 'date_posted', 'title', '-title']
    if sort_by in valid_sorts:
        items = items.order_by(sort_by)
    else:
        items = items.order_by('-date_posted')
    
    # Pagination
    paginator = Paginator(items, 9)  # 9 items per page
    page = request.GET.get('page')
    try:
        items = paginator.page(page)
    except PageNotAnInteger:
        items = paginator.page(1)
    except EmptyPage:
        items = paginator.page(paginator.num_pages)
    
    total_items = Item.objects.count()
    lost_items = Item.objects.filter(category='Lost').count()
    found_items = Item.objects.filter(category='Found').count()
    total_users = User.objects.filter(item__isnull=False).distinct().count()
    
    context = {
        'items': items,
        'total_items': total_items,
        'lost_items': lost_items,
        'found_items': found_items,
        'total_users': total_users,
        'search_query': search_query,
        'category_filter': category_filter,
        'sort_by': sort_by,
        'is_paginated': paginator.num_pages > 1,
    }
    return render(request, 'home.html', context)

@login_required
def add_item(request):
    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES)
        if form.is_valid():
            item = form.save(commit=False)
            item.user = request.user
            # If poster provided a custom display name, keep it; otherwise
            # populate `posted_by_name` with the user's full name or username
            if not item.posted_by_name:
                full_name = request.user.get_full_name()
                item.posted_by_name = full_name if full_name else request.user.username
            item.save()
            return redirect('home')
    else:
        form = ItemForm()
    return render(request, 'add_item.html', {'form': form})

@login_required
def edit_item(request, pk):
    item = get_object_or_404(Item, pk=pk)

    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES, instance=item)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = ItemForm(instance=item)

    return render(request, 'add_item.html', {'form': form})
@login_required
def delete_item(request, pk):
    item = get_object_or_404(Item, pk=pk, user=request.user)
    item.delete()
    return redirect('home')
