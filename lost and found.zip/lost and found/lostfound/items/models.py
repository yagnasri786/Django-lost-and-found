from django.db import models
from django.contrib.auth.models import User

class Item(models.Model):

    CATEGORY_CHOICES = [
        ('Lost', 'Lost'),
        ('Found', 'Found'),
    ]
    
    STATUS_CHOICES = [
        ('Open', 'Open'),
        ('Claimed', 'Claimed'),
        ('Resolved', 'Resolved'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)

    title = models.CharField(max_length=100)
    description = models.TextField()
    category = models.CharField(max_length=10, choices=CATEGORY_CHOICES)
    image = models.ImageField(upload_to='items/')
    contact_info = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Open')
    posted_by_name = models.CharField(max_length=100, blank=True, null=True, help_text='Custom display name (leave blank to use your username)')
    date_posted = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)
    location = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        ordering = ['-date_posted']
        indexes = [
            models.Index(fields=['category', '-date_posted']),
            models.Index(fields=['user', '-date_posted']),
        ]

    def __str__(self):
        return self.title
